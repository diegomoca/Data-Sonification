# MHL-Datensonifikation-Week-04-boiler
Download via .zip (don't clone this one!) and save this as the Week-04 subdirectory within your course repository.
